$(function() {
	$('.btn').click(function() {
	  $(this).toggleClass('is-clicked');
	});
  });